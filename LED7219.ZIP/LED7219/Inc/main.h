#ifndef MAIN_H_
#define MAIN_H_

#include "stm32f4xx_hal.h"
#include "max7219.h"

#endif /* MAIN_H_ */
