#ifndef MAIN_H_
#define MAIN_H_

#include "stm32f4xx.h"

uint8_t tim6_counter;

#endif /* MAIN_H_ */
