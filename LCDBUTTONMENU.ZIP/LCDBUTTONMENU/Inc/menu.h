#ifndef MENU_H_
#define MENU_H_
//------------------------------------------------
#include "stm32f4xx_hal.h"
#include "stdint.h"
#include "lcd.h"
#include "button.h"
//------------------------------------------------
typedef enum {
  MENU_STATE_IDLE = 0,
  MENU_STATE_WAIT,
  MENU_STATE_MAIN,
}MENU_StateTypeDef;

typedef enum {
  MAIN_MENU_STATE_IDLE = 0,
  MAIN_MENU_STATE_WAIT,
  MAIN_MENU_STATE_MM1,
  MAIN_MENU_STATE_MM2,
  MAIN_MENU_STATE_MM3,
  MAIN_MENU_STATE_MM4,
  MAIN_MENU_STATE_MM5,
  MAIN_MENU_STATE_EXIT,
  MAIN_MENU_STATE_MM1_WAIT,
  MAIN_MENU_STATE_MM2_WAIT,
  MAIN_MENU_STATE_MM3_WAIT,
  MAIN_MENU_STATE_MM4_WAIT,
  MAIN_MENU_STATE_MM5_WAIT,
  MAIN_MENU_STATE_EXIT_WAIT
}MAIN_MENU_StateTypeDef;
//------------------------------------------------
void MenuProcess(void);
//------------------------------------------------
#endif /* MENU_H_ */
