#include "button.h"
//------------------------------------------
uint8_t button_state[5];
static uint8_t but_cnt[5]={0};
static uint8_t tim_stat=0;
extern uint16_t ADC_Data;
extern ADC_HandleTypeDef hadc1;
uint16_t adc_value=0;
//------------------------------------------
uint8_t Read_Button_Press (uint8_t b)
{
	adc_value=ADC_Data;
	switch(b)
	{
		case Button_Right:
			if(adc_value<200) return ST_PRESSED;
			return ST_UNPRESSED;
		case Button_Up:
			if((adc_value>200)&&(adc_value<700)) return ST_PRESSED;
			return ST_UNPRESSED;
		case Button_Down:
			if((adc_value>700)&&(adc_value<1200)) return ST_PRESSED;
			return ST_UNPRESSED;
		case Button_Left:
			if((adc_value>1200)&&(adc_value<1800)) return ST_PRESSED;
			return ST_UNPRESSED;
		case Button_Select:
			if((adc_value>1800)&&(adc_value<2300)) return ST_PRESSED;
			return ST_UNPRESSED;
	}
	return ST_ERROR;
}
//------------------------------------------
void Read_Button_State (uint8_t b)
{
	if((button_state[b]&ST_LOCKED)!=0) return;	
	if(Read_Button_Press(b)==ST_UNPRESSED)
	{
		if(but_cnt[b]>0)
		{
			but_cnt[b]--;
		}
		else
		{
			if((button_state[b]&ST_PRESSED)!=0)
			{
				button_state[b]|=ST_UNPRESSURE;
				button_state[b]&=~ST_PRESSED;
				button_state[b]|=ST_UNPRESSED;
			}
		}
	}
	else
	{
		if(but_cnt[b]<5)
		{
			but_cnt[b]++;
		}
		else
		{
			if((button_state[b]&ST_UNPRESSED)!=0)
			{
				button_state[b]|=ST_PRESSURE;
				button_state[b]&=~ST_UNPRESSED;
				button_state[b]|=ST_PRESSED;
			}
		}
	}
}
//--------------------------------------------
void Button_Ini(void)
{
	uint8_t i;
	//������� �������� � ������� �������
	for(i=0;i<5;i++)
	{
		button_state[i]=ST_UNPRESSED;
	}
	tim_stat=1;
}
//--------------------------------------------
void ResetButtonState(uint8_t b, uint8_t st)
{
	button_state[b] &= ~st;
}
//--------------------------------------------
void SetButtonState(uint8_t b, uint8_t st)
{
	button_state[b] |= st;
}
//--------------------------------------------
void TIM_Callback(void)
{
	if(tim_stat==0) return;
	HAL_ADC_Stop_IT(&hadc1);
	Read_Button_State(Button_Right);
	Read_Button_State(Button_Up);
	Read_Button_State(Button_Down);
	Read_Button_State(Button_Left);
	Read_Button_State(Button_Select);
	HAL_ADC_Start_IT(&hadc1);
}
