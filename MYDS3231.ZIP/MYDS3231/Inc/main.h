#ifndef MAIN_H_
#define MAIN_H_

#include "lcd.h"
#include "i2c.h"
#include "RTC.h"
//----------------------------
uint8_t aTxBuffer[8];

#endif /* MAIN_H_ */
