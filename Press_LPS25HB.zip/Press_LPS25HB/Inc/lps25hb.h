#ifndef LPS25HB_H_
#define LPS25HB_H_

#include "stm32f4xx_hal.h"
#include <string.h>
//------------------------------------------------
#define ABS(x)         (x < 0) ? (-x) : x
//------------------------------------------------
#define LD2_Pin GPIO_PIN_5
#define LD2_GPIO_Port GPIOA
#define LD2_ON HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET) //GREEN
#define LD2_OFF HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET)
//------------------------------------------------
#define LPS25HB_ADDRESS     0xBA
//------------------------------------------------
#define	LPS25HB_WHO_AM_I_REG	0x0F
#define	LPS25HB_RES_CONF_REG	0x10
#define	LPS25HB_CTRL_REG1	0x20
//------------------------------------------------
#define	LPS25HB_WHO_AM_I	0xBD
//------------------------------------------------
#define	LPS25HB_PD_ACTIVE_MODE	0x80
#define	LPS25HB_PD_POWERDOWN_MODE	0x00
#define	LPS25HB_PD_MASK	0x80
//------------------------------------------------
#define	LPS25HB_ODR_ONE_SHOT	0x00
#define	LPS25HB_ODR_1HZ	0x10
#define	LPS25HB_ODR_7HZ	0x20
#define	LPS25HB_ODR_12_5HZ	0x30
#define	LPS25HB_ODR_25HZ	0x40
#define	LPS25HB_ODR_MASK	0x70
//------------------------------------------------
#define	LPS25HB_DIFF_EN_ENABLE	0x08
#define	LPS25HB_DIFF_EN_DISABLE	0x00
#define	LPS25HB_DIFF_EN_MASK	0x08
//------------------------------------------------
#define	LPS25HB_BDU_DISABLE	0x00
#define	LPS25HB_BDU_ENABLE	0x04
#define	LPS25HB_BDU_MASK	0x04
//------------------------------------------------
#define LPS25HB_SIM_3_WIRE	0x01
#define LPS25HB_SIM_4_WIRE	0x00
#define	LPS25HB_SIM_MASK	0x01
//------------------------------------------------
#define	LPS25HB_AVGP_8	0x00
#define	LPS25HB_AVGP_32	0x01
#define	LPS25HB_AVGP_128	0x02
#define	LPS25HB_AVGP_512	0x03
#define	LPS25HB_AVGT_8	0x00
#define	LPS25HB_AVGT_16	0x04
#define	LPS25HB_AVGT_32	0x08
#define	LPS25HB_AVGT_64	0x0C
#define	LPS25HB_AVGT_MASK	0x0C
#define	LPS25HB_AVGP_MASK	0x03
//------------------------------------------------
#define	LPS25HB_TEMP_OUT_L_REG	0x2B
#define	LPS25HB_TEMP_OUT_H_REG	0x2C
//------------------------------------------------
#define	LPS25HB_PRESS_OUT_XL_REG	0x28
#define	LPS25HB_PRESS_OUT_L_REG	0x29
#define	LPS25HB_PRESS_OUT_H_REG	0x2A
//------------------------------------------------
void Press_Ini(void);
void Press_Read(void);
//------------------------------------------------
#endif /* LIS3MDL_H_ */
