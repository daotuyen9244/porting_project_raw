#ifndef MAIN_H_
#define MAIN_H_

#include "stm32f4xx_hal.h"
#include "lis3dsh.h"
//------------------------------------------------
#define LD_PORT GPIOD
#define LD3 GPIO_PIN_13 //ORANGE
#define LD4 GPIO_PIN_12 //GREEN
#define LD5 GPIO_PIN_14 //RED
#define LD6 GPIO_PIN_15 //BLUE
#define LD3_ON HAL_GPIO_WritePin(LD_PORT, LD3, GPIO_PIN_SET) //ORANGE
#define LD4_ON HAL_GPIO_WritePin(LD_PORT, LD4, GPIO_PIN_SET) //GREEN
#define LD5_ON HAL_GPIO_WritePin(LD_PORT, LD5, GPIO_PIN_SET) //RED
#define LD6_ON HAL_GPIO_WritePin(LD_PORT, LD6, GPIO_PIN_SET) //BLUE
#define LD3_OFF HAL_GPIO_WritePin(LD_PORT, LD3, GPIO_PIN_RESET) //ORANGE
#define LD4_OFF HAL_GPIO_WritePin(LD_PORT, LD4, GPIO_PIN_RESET) //GREEN
#define LD5_OFF HAL_GPIO_WritePin(LD_PORT, LD5, GPIO_PIN_RESET) //RED
#define LD6_OFF HAL_GPIO_WritePin(LD_PORT, LD6, GPIO_PIN_RESET) //BLUE
//------------------------------------------------

#endif /* MAIN_H_ */
