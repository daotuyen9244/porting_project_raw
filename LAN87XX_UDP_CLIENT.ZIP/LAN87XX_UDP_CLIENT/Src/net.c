#include "net.h"
#include "lcd.h"
//-----------------------------------------------
struct udp_pcb *upcb;
char str1[30];
//-----------------------------------------------
void udp_receive_callback(void *arg, struct udp_pcb *upcb, struct pbuf *p, const ip_addr_t *addr, u16_t port);
//-----------------------------------------------
void udp_client_connect(void)
{
  ip_addr_t DestIPaddr;
  err_t err;
  upcb = udp_new();
  if (upcb!=NULL)
  {
  	IP4_ADDR(&DestIPaddr, 192, 168, 1, 191);
  	upcb->local_port = 1555;
  	err= udp_connect(upcb, &DestIPaddr, 7);
  	if (err == ERR_OK)
  	{
  	  udp_recv(upcb, udp_receive_callback, NULL);
  	}
  }
}
//-----------------------------------------------
void udp_client_send(void)
{
  struct pbuf *p;
  uint32_t gt;
  uint16_t port;
  sprintf(str1,"%lu\r\n",HAL_GetTick());
  p = pbuf_alloc(PBUF_TRANSPORT, strlen(str1), PBUF_POOL);
  port = upcb->local_port;
  if (p != NULL)
  {
  	gt = HAL_GetTick();
    pbuf_take(p,  (void *) &gt, 4);
    udp_send(upcb, p);
    sprintf(str1,"%10lu", gt);
    LCD_SetPos(0,0);
    LCD_String(str1);
    pbuf_free(p);
  }
}
//-----------------------------------------------
void udp_receive_callback(void *arg, struct udp_pcb *upcb, struct pbuf *p, const ip_addr_t *addr, u16_t port)
{

	sprintf(str1,"%5u %7lu", port, *(uint32_t*) p->payload);
	LCD_SetPos(0,1);
	LCD_String(str1);
  pbuf_free(p);
  HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_12);
}
//-----------------------------------------------
void TIM1_Callback(void)
{
	udp_client_send();
  HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_15);
}
//--------------------------------------------------
