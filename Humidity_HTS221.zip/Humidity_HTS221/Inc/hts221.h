#ifndef HTS221_H_
#define HTS221_H_

#include "stm32f4xx_hal.h"
#include <string.h>
//------------------------------------------------
#define ABS(x)         (x < 0) ? (-x) : x
//------------------------------------------------
#define LD2_Pin GPIO_PIN_5
#define LD2_GPIO_Port GPIOA
#define LD2_ON HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET) //GREEN
#define LD2_OFF HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET)
//------------------------------------------------
#define	HTS221_ADDRESS	0xBE
//------------------------------------------------
#define	HTS221_WHO_AM_I_REG	0x0F
#define	HTS221_CTRL_REG1	0x20
//------------------------------------------------
#define	HTS221_WHO_AM_I_VAL	0xBC
//------------------------------------------------
#define	HTS221_PD_ACTIVE_MODE	0x80
#define	HTS221_PD_POWERDOWN_MODE	0x00
#define	HTS221_PD_MASK	0x80
//------------------------------------------------
#define	HTS221_ODR_ONE_SHOT	0x00
#define	HTS221_ODR_1HZ	0x01
#define	HTS221_ODR_7HZ	0x02
#define	HTS221_ODR_12_5HZ	0x03
#define	HTS221_ODR_MASK	0x03
//------------------------------------------------
#define	HTS221_BDU_DISABLE	0x00
#define	HTS221_BDU_ENABLE	0x04
#define	HTS221_BDU_MASK	0x04
//------------------------------------------------
#define HTS221_HR_OUT_L_REG	0x28
#define HTS221_HR_OUT_H_REG	0x29
#define	HTS221_H0_RH_X2	0x30
#define	HTS221_H1_RH_X2	0x31
#define	HTS221_T0_DEGC_X8	0x32
#define	HTS221_T1_DEGC_X8	0x33
#define	HTS221_T0_T1_DEGC_H2	0x35
#define	HTS221_H0_T0_OUT_L	0x36
#define	HTS221_H0_T0_OUT_H	0x37
#define	HTS221_H1_T0_OUT_L	0x3A
#define	HTS221_H1_T0_OUT_H	0x3B
#define	HTS221_T0_OUT_L	0x3C
#define	HTS221_T0_OUT_H	0x3D
#define	HTS221_T1_OUT_L	0x3E
#define	HTS221_T1_OUT_H	0x3F
#define HTS221_TEMP_OUT_L_REG	0x2A
#define HTS221_TEMP_OUT_H_REG	0x2B
//------------------------------------------------
void Humidity_Ini(void);
void Humidity_Read(void);
//------------------------------------------------
#endif /* HTS221_H_ */
