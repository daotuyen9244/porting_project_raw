#include "net.h"
//-----------------------------------------------
extern UART_HandleTypeDef huart2;
//-----------------------------------------------
uint8_t ipaddr[4]=IP_ADDR;
uint8_t ipgate[4]=IP_GATE;
uint8_t ipmask[4]=IP_MASK;
uint16_t local_port = LOCAL_PORT;
uint16_t local_port_ftp_control = LOCAL_PORT_FTP_CONTROL;
uint16_t local_port_ftp_data = LOCAL_PORT_FTP_DATA;
uint16_t local_port_ftp_data_passiv = LOCAL_PORT_FTP_DATA_PASSIV;
char str1[60]={0};
//-----------------------------------------------
void packet_receive(void)
{
	uint8_t i;
	for(i=0;i<SOCKET_MAX;i++)
	{
		w5500_packetReceive(i);
	}
}
//-----------------------------------------------
void net_poll(void)
{
  packet_receive();
}
//-----------------------------------------------
void net_ini(void)
{
	w5500_ini();
}
//-----------------------------------------------
